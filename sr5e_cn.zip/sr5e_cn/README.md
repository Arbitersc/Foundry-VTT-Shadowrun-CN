# Foundry-VTT-Shadowrun-CN
本MOD为Shadowrun 5E 添加中文支持
